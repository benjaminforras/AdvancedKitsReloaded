package hu.tryharddood.advancedkits.Commands;

import hu.tryharddood.advancedkits.AdvancedKits;
import hu.tryharddood.advancedkits.InventoryApi.ItemBuilder;
import hu.tryharddood.advancedkits.InventoryApi.PageInventory;
import hu.tryharddood.advancedkits.Kits.Kit;
import hu.tryharddood.advancedkits.Variables;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static hu.tryharddood.advancedkits.Utils.I18n.tl;


/**
 * Class:
 *
 * @author TryHardDood
 */
public class MainCommand extends Subcommand {
	@Override
	public String getPermission() {
		return Variables.KIT_USE_PERMISSION;
	}

	@Override
	public String getUsage() {
		return "/kit";
	}

	@Override
	public String getDescription() {
		return "Opens up the kit GUI";
	}

	@Override
	public int getArgs() {
		return 0;
	}

	@Override
	public boolean playerOnly() {
		return true;
	}

	@Override
	public void onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player player = (Player) sender;

		PageInventory inv = new PageInventory(player);

		List<Kit> kits = AdvancedKits.getKitManager().getKits().entrySet().stream().map(Map.Entry::getValue).collect(Collectors.toList());

		Kit             kit;
		List<String>    lore   = new ArrayList<>();
		List<ItemStack> items  = new ArrayList<>();
		int             delete = 0;

		for (int i = 0; i < kits.size(); i++)
		{
			if (!kits.get(i).isVisible() && (!player.hasPermission(Variables.KITADMIN_PERMISSION) && AdvancedKits.getKitManager().getUses(kits.get(i), player) >= kits.get(i).getUses()))
			{
				continue;
			}

			if (!player.hasPermission(Variables.KIT_USE_KIT_PERMISSION_ALL))
			{
				if (!player.hasPermission(kits.get(i).getPermission()) && !player.hasPermission(Variables.KITADMIN_PERMISSION))
				{
					continue;
				}
			}

			lore.clear();

			kit = kits.get(i);

			if (!AdvancedKits.getKitManager().CheckCooldown(player, kit))
			{
				lore.add("§8");
				lore.add(ChatColor.RED + "" + ChatColor.BOLD + tl("kituse_wait").replaceAll("\\{(\\d*?)\\}", "") + ":");
				lore.add(ChatColor.WHITE + "" + ChatColor.BOLD + "- " + AdvancedKits.getKitManager().getDelay(player, kit));
				lore.add("§8");
			}

			items.add(new ItemBuilder(kit.getIcon()).setTitle(ChatColor.translateAlternateColorCodes('&', kit.getDisplayName())).addLores(lore).addLores(AdvancedKits.getKitManager().getLores(player, kit)).build());
		}
		inv.setPages(items.stream().toArray(ItemStack[]::new));
		inv.setTitle("Kits");
		inv.openInventory();
	}
}
